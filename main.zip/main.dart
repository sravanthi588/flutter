import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
     initialRoute: '/',
       routes:{
        '/':(context)=>HomePage(),
        '/second':(context)=>Secondpage(),
       },
    );
  }
}
class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Home page'),
 ),
 body: Center(
  child: ElevatedButton(
    onPressed: () {
      Navigator.pushNamed(context,'/second');
    },
   child: Text('Go to Second page'),
     ),
    ),
);
  }
}
class Secondpage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Second page'),
      ),
      body: Center(
        child: ElevatedButton(
          onPressed: () {
          Navigator.pop(context);
          },
          child: Text('Go back to Home Page')
      ),
 ),
    );
  }
}
